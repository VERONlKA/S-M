package com.snake.game.state;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.snake.game.SnakeGame;

public class ChooseAnAction extends State {
    private Texture background;
    private Texture addition;
    private Texture division;
    private Texture multiplication;
    private Texture substraction;
    private Texture back;
    private Texture settingsBtn;

    private Sprite backSprite;
    private SpriteBatch batch;

    public ChooseAnAction(GameStateManager gsm) {
        super(gsm);

        background  = new Texture("lakeBG.JPEG");
        addition  = new Texture("addition.PNG");
        substraction = new Texture("substraction.PNG");
        division = new Texture("division.PNG");
        multiplication = new Texture("multiplication.PNG");

       // back = new Texture("return.PNG");
        settingsBtn = new Texture("settingsButton.PNG");//to do: button push
    }

    public void create(){
        back = new Texture("return.PNG");
        batch = new SpriteBatch();
        backSprite= new Sprite(back, 00,0, 60,60);
        backSprite.setSize(60,60);
        backSprite.setPosition(70, 700);
    }

    @Override
    protected void handleInput() {
        if (Gdx.input.isTouched()) {
            if (backSprite.getBoundingRectangle().contains(Gdx.input.getX(), Gdx.graphics.getHeight()-Gdx.input.getY())) {
                dispose();
            }
        }
    }

    @Override
    public void update(float dt) {

    }

    @Override
    public void render(SpriteBatch sb) {
        sb.begin();
        sb.draw(background, 0,0, SnakeGame.WIDTH, SnakeGame.HEGHT );
        sb.draw(back, 70,700, 60,60);

        sb.draw(settingsBtn, 345, 700, 60,60);
        sb.draw(addition, 60,380, 180,180);
        sb.draw(substraction, 240, 380, 180,180);
        sb.draw(multiplication,60,220, 180,180);
        sb.draw(division,240, 220, 180,180);

        camera.setToOrtho(false, SnakeGame.WIDTH , SnakeGame.HEGHT);
        sb.end();

        batch.begin();
        backSprite.draw(batch);
        batch.end();
    }

    @Override
    public void dispose() {
        background.dispose();
        back.dispose();
        addition.dispose();
        substraction.dispose();
        multiplication.dispose();
        division.dispose();
        settingsBtn.dispose();
    }
}
