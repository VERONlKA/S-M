package com.snake.game.state;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.snake.game.SnakeGame;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.snake.game.state.GameStateManager;

public class StartScreen implements Screen {

    OrthographicCamera camera;
    private Texture backGroundTexture;
    private Texture startButtonTexture;
    private Texture logoTexture;
    private Sprite startButtonSprite;
    private Sprite backGroundSprite;
    private SpriteBatch batch;
    private SnakeGame game;


    public StartScreen(final SnakeGame gam) {

        this.game = gam;
        camera = new OrthographicCamera();
        camera.setToOrtho(false, SnakeGame.WIDTH , SnakeGame.HEGHT);
        batch = new SpriteBatch();
    }

    @Override
    public void show() {
        logoTexture = new Texture("logoSnake.png");
        backGroundTexture = new Texture("menuBackGR.jpg");
        startButtonTexture = new Texture("playButton.png");


        startButtonSprite=new Sprite(startButtonTexture);
        backGroundSprite = new Sprite(backGroundTexture);


        startButtonSprite.setSize(105,105);
        startButtonSprite.setPosition(190, 140);

        backGroundSprite.setSize(SnakeGame.WIDTH , SnakeGame.HEGHT);
        backGroundSprite.setPosition(0,0);
        backGroundSprite.setAlpha(1);
    }

    @Override
    public void render(float delta) {
        batch.begin();
        batch.draw(logoTexture, 95, 245, 290,290);
        batch.setProjectionMatrix(camera.combined);
        batch.end();

    }

    @Override
    public void resize(int width, int height) { }
    @Override
    public void pause() { }
    @Override
    public void resume() { }
    @Override
    public void hide() { }

    @Override
    public void dispose() {
        backGroundTexture.dispose();
        startButtonTexture.dispose();
        logoTexture.dispose();
    }

}
